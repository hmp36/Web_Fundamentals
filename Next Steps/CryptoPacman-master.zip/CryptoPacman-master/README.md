An HTML/CSS/JavaScript driven demo of DOM manipulation

The "world" in the HTML file is completely customizable

"CryptoPacman" collects Ether and Bitcoin

Score amounts approximate current values of cryptocurrencies
