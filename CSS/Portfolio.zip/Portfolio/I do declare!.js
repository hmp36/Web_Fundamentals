var num1 = 10;
var num2 = -5;
var num3 = 7;
var num4 = 6.4;
var x

var myname="hagan";
var food="chicken";
var birthmonth="November";

var itssnowing = true;
var itshot = false;

console.log("The first number is " + num1);
console.log("The second number is " + num2);
console.log("The third number is " + num3);
console.log("The fourth number is " + num4);
console.log("My name is " + myname);
console.log("my favorite food is " + food);
console.log("I was born in " + birthmonth);
console.log( itssnowing);
console.log( itshot);







