# Pokemon
using jQuery to display all the original Pokemon (pokemon#1 - pokemon#151) from pokeAPI, then make ajax calls to "http://pokeapi.co/api/v1/pokemon/ "and extract and display information about the individual pokemon from the response that comes back from the pokemon server. See task below.
![Alt text](https://raw.github.com/kevinbundi/Pokemon/master/Capture.jpg)

My outcome
![Alt text](https://raw.github.com/kevinbundi/Pokemon/master/Capture_2.PNG) 
